import React, { Component } from 'react';
import { connect } from 'react-redux';

class Result extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { login } = this.props;
        return (
        <div>{JSON.stringify(login)}</div>
       )



    }
};

const mapStateToProps =(state) => {
    return {
        login : state.login
    }
};

const mapDispatchToProps =(dispatch) => {
   return {
    dispatch
   }
};
 
export default connect(mapStateToProps,mapDispatchToProps)(Result);
