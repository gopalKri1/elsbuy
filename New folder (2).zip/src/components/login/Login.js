import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { loginServiceCall } from '../../common/service';
import { connect } from 'react-redux';
import { loginResponse } from '../../reducers/login';
import { Field, reduxForm } from 'redux-form';


class Login extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        fields: {},
        errors: {}
    }
    handleData = (event) => {
        let name = event.target.name
        this.setState({
            [name]: event.target.checked
        })
    }

    handleChange(field, e){         
        let fields = this.state.fields;
        fields[field] = e.target.value;        
        this.setState({fields});
    }
    handleValidation(){
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        //Name
        if(!fields["userName"]){
           formIsValid = false;
           errors["userName"] = "required";
        }

        if(!fields["password"]){
            formIsValid = false;
            errors["password"] = "required";
         }

       

       this.setState({errors: errors});
       return formIsValid;
   }
    contactSubmit(e){
        e.preventDefault();

        if(this.handleValidation()){
            loginServiceCall("7981265318", "elsbuly").then(
                       (response) => {
                            this.props.dispatch(loginResponse(response));
                            this.props.history.push('/sucess')
                        }
                    );
        }else{
           alert("Form has errors.")
        }

    }

    render() {
        const { dispatch } = this.props;
        return (
            <div className="login-page">

                <div className="row no-gutters justify-content-md-center">

                    <div className="col-12 col-sm-4 col-md-4 col-lg-3">

                        <div className="LP-logo ">
                            <img src="images/logo.png" />
                        </div>

                        <div className="M-textfield">
                            <input type="text" name="userName" //onChange={this.handleData} 
                             //value="7981265318"
                             onChange={this.handleChange.bind(this, "userName")} value={this.state.fields["userName"]}
                             required className="w-100" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>User Name</label>
                            <span style={{color: "red"}}>{this.state.errors["userName"]}</span>
                        </div>

                        <div className="M-textfield">
                            <input type="text" name="password" 
                            //onChange={this.handleData} 
                            //value="elsbuly"
                            onChange={this.handleChange.bind(this, "password")} value={this.state.fields["password"]}
                             required className="w-100" />
                            <span className="highlight"></span>
                            <span className="bar"></span>
                            <label>Password</label>
                            <span style={{color: "red"}}>{this.state.errors["password"]}</span>
                        </div>

                        <div class="row no-gutters LP-Forgot">
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="gridCheck" />
                                    <label class="form-check-label" for="gridCheck">
                                        Remember me
                                </label>
                                </div>
                            </div>
                            <div class="col-6 text-right">
                                <a href=""> Forgot Password?</a>
                            </div>
                        </div>
                        <button type="button" class="btn login-btn btn-block" 
                        onClick= {this.contactSubmit.bind(this)}
                        
                        // onClick={() => {
                        //     loginServiceCall("7981265318", "elsbuly").then(
                        //         (response) => {
                        //             dispatch(loginResponse(response));
                        //             this.props.history.push('/sucess')
                        //         }
                        //     );
                        // }}
                        >Login</button>
                        <div class="LP-Signup">
                            Don’t have an account ? <a href=""> Sign Up</a>
                        </div>

                    </div>

                </div>

            </div>)



    }
};

const mapStateToProps = (state) => {
    console.log(JSON.stringify(state));
};

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch
    }
};

// export default 
export default reduxForm({
    form: 'simple', // a unique identifier for this form
})(withRouter(connect(mapStateToProps, mapDispatchToProps)(Login)));
