import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { loginServiceCall } from '../../common/service';
import { connect } from 'react-redux';
import { loginResponse } from '../../reducers/login';
import { Field, reduxForm } from 'redux-form';


class SignupOTP extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        fields: {},
        errors: {}
    }
    handleData = (event) => {
        let name = event.target.name
        this.setState({
            [name]: event.target.checked
        })
    }

    handleChange(field, e) {
        let fields = this.state.fields;
        fields[field] = e.target.value;
        this.setState({ fields });
    }
    handleValidation() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        //Name
        // if (!fields["userName"]) {
        //     formIsValid = false;
        //     errors["userName"] = "required";
        // }

        // if (!fields["password"]) {
        //     formIsValid = false;
        //     errors["password"] = "required";
        // }



        // this.setState({ errors: errors });
        return formIsValid;
    }
    contactSubmit(e) {
        e.preventDefault();

        this.props.history.push('/signupotp')

        // if (this.handleValidation()) {
        //     loginServiceCall("7981265318", "elsbuly").then(
        //         (response) => {
        //             this.props.dispatch(loginResponse(response));
        //             this.props.history.push('/sucess')
        //         }
        //     );
        // } else {
        //     alert("Form has errors.")
        // }

    }

    render() {
        const { dispatch } = this.props;
        return (
            <div className="signup-page">
                <div className="topbar">
                    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a className="navbar-brand" href="#"><img src="images/logo-tran.png" height="40px" /></a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav mr-auto">
                            </ul>
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Privacy Policy</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Terms of Use</a>
                                </li>
                            </ul>

                        </div>
                    </nav>
                </div>
                <div className="SP-pad">
                    <div className="steps text-center">
                        <ul className="list-unstyled multi-steps">
                            <li >Account Details</li>
                            <li className="is-active">Verify OTP</li>
                            <li >Finish!</li>
                        </ul>
                    </div>
                    <div className="row no-gutters justify-content-md-center">
                        <div className="col-12 col-sm-4 col-md-4 col-lg-3">


                            <div className="LP-Rbtns text-center">
                                Please Enter the OPT to Verify Your Account
                    </div>
                            <div className="OTP">
                                <input type="" name="" className="Input-small" />
                                <input type="" name="" className="Input-small" />
                                <input type="" name="" className="Input-small" />
                                <input type="" name="" className="Input-small" />
                            </div>

                            <button type="button" className="btn login-btn btn-block" onClick={()=> {  this.props.history.push('/signupFinish'); }}>Continue</button>

                            <div className="text-center" style={{paddingtTop: "15px"}}>
                                <a href="#" className="RS-link">Resent OTP</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        )



    }
};

const mapStateToProps = (state) => {
    console.log(JSON.stringify(state));
};

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch
    }
};

// export default 
export default reduxForm({
    form: 'simple', // a unique identifier for this form
})(withRouter(connect(mapStateToProps, mapDispatchToProps)(SignupOTP)));
