import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { loginServiceCall } from '../../common/service';
import { connect } from 'react-redux';
import { loginResponse } from '../../reducers/login';
import { Field, reduxForm } from 'redux-form';


class Signup extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        fields: {},
        errors: {}
    }
    handleData = (event) => {
        let name = event.target.name
        this.setState({
            [name]: event.target.checked
        })
    }

    handleChange(field, e) {
        let fields = this.state.fields;
        fields[field] = e.target.value;
        this.setState({ fields });
    }
    handleValidation() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        //Name
        if (!fields["userName"]) {
            formIsValid = false;
            errors["userName"] = "required";
        }

        if (!fields["password"]) {
            formIsValid = false;
            errors["password"] = "required";
        }



        this.setState({ errors: errors });
        return formIsValid;
    }
    contactSubmit(e) {
        e.preventDefault();

        if (this.handleValidation()) {
            loginServiceCall("7981265318", "elsbuly").then(
                (response) => {
                    this.props.dispatch(loginResponse(response));
                    this.props.history.push('/sucess')
                }
            );
        } else {
            alert("Form has errors.")
        }

    }

    render() {
        const { dispatch } = this.props;
        return (
            <div className="signup-page">
                <div className="topbar">
                    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a className="navbar-brand" href="#"><img src="images/logo-tran.png" height="40px" /></a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav mr-auto">
                            </ul>
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Privacy Policy</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Terms of Use</a>
                                </li>
                            </ul>

                        </div>
                    </nav>
                </div>

                <div className="SP-pad">
                    <h2 className="text-center">Free Member Registration</h2>
                    <div className="steps text-center">
                        <ul className="list-unstyled multi-steps">
                            <li className="is-active">Account Details</li>
                            <li >Verify OTP</li>
                            <li >Finish!</li>
                        </ul>
                    </div>
                    <div className="row no-gutters justify-content-md-center">
                        <div className="col-12 col-sm-9">
                            <p>Become a member of Investopedia and receive free instant access to exclusive features including our Stock Simulator, Newsletters, and Exam Prep Quizzer.</p>
                            <div className="row">
                                <div className="col-12 col-sm-4">
                                    <div className="form-group">
                                        <label for="exampleInputEmail1">First Name</label>
                                        <input type="email" className="form-control" />
                                    </div>
                                </div>

                                <div className="col-12 col-sm-4">
                                    <div className="form-group">
                                        <label for="exampleInputEmail1">Last Name</label>
                                        <input type="email" className="form-control" />
                                    </div>
                                </div>
                                <div className="col-12 col-sm-4">
                                    <div className="form-group">
                                        <label for="exampleInputEmail1">Mobile Number</label>
                                        <input type="email" className="form-control" />
                                    </div>
                                </div>
                                <div className="col-12 col-sm-4">
                                    <div className="form-group">
                                        <label for="exampleInputEmail1">Password</label>
                                        <input type="email" className="form-control" />
                                    </div>
                                </div>
                                <div className="col-12 col-sm-4">
                                    <div className="form-group">
                                        <label for="exampleInputEmail1">Confirm password</label>
                                        <input type="email" className="form-control" />
                                    </div>
                                </div>
                            </div>
                            <h5>Are you an Advisor or Trader?*</h5>
                            <div className="LP-Rbtns">
                                <div className="form-check form-check-inline">
                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                    <label className="form-check-label" for="inlineRadio1">Adviosr</label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                                    <label className="form-check-label" for="inlineRadio2">Trader</label>
                                </div>
                            </div>

                            <div className="">
                                <button type="button" className="btn login-btn " onClick={()=> {  alert("alert");this.props.history.push('/signupotp'); }}>Next</button>
                            </div>
                            <div className="LP-Signup">
                                By creating an account, I agree to the <a href="#">Terms Of Use</a> and Privacy & <a href="#">Cookie Policy</a>.
                    </div>
                            <div className="LP-Signup">
                                Already have an account?  <a href=""> Sign In</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )



    }
};

const mapStateToProps = (state) => {
    console.log(JSON.stringify(state));
};

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch
    }
};

// export default 
export default reduxForm({
    form: 'simple', // a unique identifier for this form
})(withRouter(connect(mapStateToProps, mapDispatchToProps)(Signup)));
