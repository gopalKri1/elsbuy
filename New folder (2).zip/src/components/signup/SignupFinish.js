import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { loginServiceCall } from '../../common/service';
import { connect } from 'react-redux';
import { loginResponse } from '../../reducers/login';
import { Field, reduxForm } from 'redux-form';


class SignupFinish extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        fields: {},
        errors: {}
    }
    handleData = (event) => {
        let name = event.target.name
        this.setState({
            [name]: event.target.checked
        })
    }

    handleChange(field, e) {
        let fields = this.state.fields;
        fields[field] = e.target.value;
        this.setState({ fields });
    }
    handleValidation() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        //Name
        // if (!fields["userName"]) {
        //     formIsValid = false;
        //     errors["userName"] = "required";
        // }

        // if (!fields["password"]) {
        //     formIsValid = false;
        //     errors["password"] = "required";
        // }



        // this.setState({ errors: errors });
        return formIsValid;
    }
    contactSubmit(e) {
        e.preventDefault();

        this.props.history.push('/signupotp')

        // if (this.handleValidation()) {
        //     loginServiceCall("7981265318", "elsbuly").then(
        //         (response) => {
        //             this.props.dispatch(loginResponse(response));
        //             this.props.history.push('/sucess')
        //         }
        //     );
        // } else {
        //     alert("Form has errors.")
        // }

    }

    render() {
        const { dispatch } = this.props;
        return (
            <div class="signup-page">
                <div class="topbar">
                    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                        <a class="navbar-brand" href="#"><img src="images/logo-tran.png" height="40px" /></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                            </ul>
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Privacy Policy</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Terms of Use</a>
                                </li>
                            </ul>

                        </div>
                    </nav>
                </div>
                <div class="SP-pad">
                    <div class="steps text-center">
                        <ul class="list-unstyled multi-steps">
                            <li >Account Details</li>
                            <li >Verify OTP</li>
                            <li >Finish!</li>
                        </ul>
                    </div>
                    <div class="row no-gutters justify-content-md-center">
                        <div class="col-12 col-sm-4 col-md-4 col-lg-3">

                            <div class="text-center" style={{ "paddingBottom": "20px;" }}>
                                <img src="images/check.svg" width="80px" />
                            </div>
                            <div class="LP-Rbtns text-center">
                                You have successfully registerd
                    </div>


                            <button type="button" class="btn login-btn btn-block">Welcome</button>



                        </div>
                    </div>
                </div>
            </div>

        )



    }
};

const mapStateToProps = (state) => {
    console.log(JSON.stringify(state));
};

const mapDispatchToProps = (dispatch) => {
    return {
        dispatch
    }
};

// export default
export default reduxForm({
    form: 'simple', // a unique identifier for this form
})(withRouter(connect(mapStateToProps, mapDispatchToProps)(SignupFinish)));
