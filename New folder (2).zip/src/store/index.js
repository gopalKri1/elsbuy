import { createStore } from "redux";
import login from "../reducers/login";
import { combineReducers } from 'redux';
import { reducer as reduxFormReducer } from 'redux-form';


const store = createStore(combineReducers({
    login,
    reduxFormReducer
  }));
export default store;