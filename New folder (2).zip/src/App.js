import React,{ Component } from 'react';
import './App.css';
import Login from './components/login/Login';
import Result from './components/Result/Result';
import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom';
import Signup from './components/signup/Signup';
import SignupOTP from './components/signup/SignupOTP';
import SignupFinish from './components/signup/SignupFinish';

export class App extends Component {
  render() {
    return (
      <Router>
        <Route exact path="/login" component={Login} />
        <Route exact path="/signup" component={Signup} />
        <Route exact path="/signupotp" component={SignupOTP} />
        <Route exact path="/signupFinish" component={SignupFinish} />
        <Route path="/sucess" component={Result} />
      </Router>
    );

  }
}



