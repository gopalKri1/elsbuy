import { LOGIN } from "../constants/action-types";

const initialState = {
    isLogin : false
};


export default function login(state = initialState, action) {
    switch (action.type) {
        case LOGIN:
          return Object.assign({}, state, {... action.payload, ... {    isLogin : true }})
        
        default:
          return state
      }
};



export function loginResponse(payload) {
  return { type: LOGIN , payload };
}