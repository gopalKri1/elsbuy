import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { loginServiceCall } from '../../common/service';
import { connect } from 'react-redux';
import { loginResponse } from '../../reducers/login';
import { Field, reduxForm } from 'redux-form';

export const CustomTextField = props => {
    const { input, label, type, meta: { touched, error }, ...other } = props
  
    return (
      <TextField
        label={label}
        type={type}
        error={!!(touched && error)}
        helperText={touched && error}
        { ...input }
        { ...other }
      />
    )
  }
class Login extends Component {
    constructor(props) {
        super(props);
    }
     state = {
         userName : "",
     }
    handleData = (event) => {
        let name = event.target.name
        this.setState({
          [name]: event.target.checked
        })
      }
    

    render() {
        const { dispatch } = this.props;
        return (
        <div className="login-page">

            <div className="row no-gutters justify-content-md-center">

                <div className="col-12 col-sm-4 col-md-4 col-lg-3">

                    <div className="LP-logo ">
                        <img src="images/logo.png" />
                    </div>

                    <div className="M-textfield">
                    <Field
                        name="userName"
                        component={CustomTextField}
                        className="w-100"
                        />
                        {/* <input type="text" name = "userName" value = "7981265318" required class="w-100" /> */}
                        <span className="highlight"></span>
                        <span className="bar"></span>
                        <label>User Name</label>
                    </div>

                    <div className="M-textfield">
                        <input type="text" name = "password" value = "elsbuly" required className="w-100" />
                        <span className="highlight"></span>
                        <span className="bar"></span>
                        <label>Password</label>
                    </div>

                    <div class="row no-gutters LP-Forgot">
                        <div class="col-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gridCheck" />
                                <label class="form-check-label" for="gridCheck">
                                    Remember me
                                </label>
                            </div>
                        </div>
                        <div class="col-6 text-right">
                            <a href=""> Forgot Password?</a>
                        </div>
                    </div>
                    <button type="button" class="btn login-btn btn-block" onClick={() => { 
                        loginServiceCall("7981265318","elsbuly").then(
                            (response)=>{
                                dispatch(loginResponse(response));
                                this.props.history.push('/sucess')
                            }
                        );
                         }}>Login</button>
                    <div class="LP-Signup">
                        Don’t have an account ? <a href=""> Sign Up</a>
                    </div>

                </div>

            </div>

        </div>)



    }
};

const mapStateToProps =(state) => {
    console.log(JSON.stringify(state));
};

const mapDispatchToProps =(dispatch) => {
   return {
    dispatch
   }
};
 
// export default 
export default reduxForm({
    form: 'simple', // a unique identifier for this form
  })(withRouter(connect(mapStateToProps,mapDispatchToProps)(Login)));
