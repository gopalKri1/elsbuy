import React,{ Component } from 'react';
import './App.css';
import Login from './components/login/Login';
import Result from './components/Result/Result';
import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom';
export class App extends Component {
  render() {
    return (
      <Router>
        <Route exact path="/login" component={Login} />
        <Route path="/sucess" component={Result} />
      </Router>
    );

  }
}



