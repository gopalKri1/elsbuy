import axios from 'axios';

const BASE_URI = "https://elsbulyauthservice.cfapps.io";


const LOGIN = `${BASE_URI}/login`;

export const loginServiceCall = (userName, password) => new Promise(function (resolve, reject) {
    axios.post(LOGIN, {
        userName,
        password
    })
        .then((response) => {
            resolve(response.data.loginUserDetails);
        })
        .catch((error) => {
            reject(error);
        });
});

